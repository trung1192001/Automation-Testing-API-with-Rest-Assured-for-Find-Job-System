package com.api.auto.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;
import java.util.Random;

import org.testng.Assert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class PropertiesFileUtils {
	
	//Lấy thông tin propertis
	public static String getProperties(String key) {
		String value = null;
		FileInputStream fileInputStream = null;
		Properties properties = new Properties();
		
		try {
			fileInputStream = new FileInputStream("./configuration/config.properties");
			properties.load(fileInputStream);
			value = properties.getProperty(key);
		}
		catch (Exception e) {
			System.out.println("Có lỗi xảy ra khi lấy dữ liệu");
			e.printStackTrace();
		}
		finally {
			if(fileInputStream != null) {
				try {
					fileInputStream.close();
				} catch (Exception e2) {
					System.out.println("Xảy ra lỗi khi đóng FileInputStream");
					e2.printStackTrace();
				}
			}
		}
		
		return value;
	}
	
	//Ghi thông tin properties
	public static void setProperty(String key, String value) {
		Properties properties = new Properties();
		FileOutputStream fileOutputStream = null;
		FileInputStream fileInputStream = null;
		try {
			fileInputStream = new FileInputStream("./configuration/config.properties");
			properties.load(fileInputStream);
			
			properties.setProperty(key, value);
			fileOutputStream = new FileOutputStream("./configuration/config.properties");;
			properties.store(fileOutputStream, null);
			
		} catch (Exception e) {
			System.out.println("Xảy ra lỗi khi lưu dữ liệu");
			e.printStackTrace();
		}
		finally {
			if(fileOutputStream != null) {
				try {
					fileOutputStream.close();
				} catch (Exception e2) {
					System.out.println("Xảy ra lỗi khi đóng FileOutputStream");
					e2.printStackTrace();
				}
			}
			if(fileInputStream != null) {
				try {
					fileInputStream.close();
				} catch (Exception e2) {
					System.out.println("Xảy ra lỗi khi đóng FileInputStream");
					e2.printStackTrace();
				}
			}
		}
	}
	
	//Kiểm tra trạng thái phản hồi
	public static void getStatus(Response response, int expected) {
		Assert.assertEquals(response.getStatusCode(), expected, "Status code phản hồi không giống mô tả");
	}
	
	//Kiểm tra trường thông tin phản hồi
	public static void ContainKey(ResponseBody resBody,String key) {
		Assert.assertTrue(resBody.asString().contains(key), "Trường thông tin " + key + " không phản hồi");
	}
	
	//Kiểm tra thông tin phản hồi
	public static void CompareValue(JsonPath bodyJson, String key, String expected) {
		Assert.assertEquals(bodyJson.get(key), expected, "Thông tin " + key + " phản hồi không giống");
	}
	
	//Kiểm tra trường thông tin có tồn tại giá trị
	public static void ContainValue(JsonPath bodyJson, String key) {
		Assert.assertTrue(bodyJson.get(key) != null, "Trường " + key + " không chứa dữ liệu");
	}
		
	//Kiểm tra trường thông tin có bên trong 1 trường thông tin khác
	public static void ContainKeyInField(JsonPath bodyJson, String field, String key) {
		Assert.assertTrue(bodyJson.get(field).toString().contains(key), "Trường " + field + " không chứa dữ liệu " + key);
	}
	
	//Lấy giá trị random để đăng ký
	public static String setRandomValueAccount() {
		int length = 7;
		Random random = new Random();
		StringBuilder stringBuilder = new StringBuilder();
		String character = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		
		for (int i =0; i < length; i++) {
			int index = random.nextInt(character.length());
			char charAt = character.charAt(index);
			stringBuilder.append(charAt);
		}
		
		return stringBuilder.toString();
	}
	
	//Lấy random số
	public static String setRandomNumber() {
		int length = 10;
		Random random = new Random();
		StringBuilder stringBuilder = new StringBuilder();
		String character = "0123456789";
		
		for (int i =0; i < length; i++) {
			int index = random.nextInt(character.length());
			char charAt = character.charAt(index);
			stringBuilder.append(charAt);
		}
		
		return stringBuilder.toString();
	}
}	
	
	

	

