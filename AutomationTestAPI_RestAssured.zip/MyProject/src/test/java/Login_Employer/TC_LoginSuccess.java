package Login_Employer;

import org.apache.http.params.CoreConnectionPNames;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.api.auto.utils.PropertiesFileUtils;

import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_LoginSuccess {
	private Response response;
	private ResponseBody resBody;
	private JsonPath bodyJson;
	
	@BeforeClass
	public void Init() {
		String bodyInfo = "{\"account\" : \"" + PropertiesFileUtils.getProperties("account_employer(success)") + "\", \"password\" : \""
				+ PropertiesFileUtils.getProperties("password_employer(success)") + "\"}";
		
		HttpClientConfig httpClientConfig = HttpClientConfig
				.httpClientConfig()
				.setParam(CoreConnectionPNames.SO_TIMEOUT, 5000)
				.setParam(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);

		RestAssured.config = RestAssuredConfig.config().httpClient(httpClientConfig);

		RequestSpecification req = RestAssured.given()
								.contentType(ContentType.JSON)
								.body(bodyInfo);
		
		response = req.post("http://34.143.239.189:5000/api/company/login-company");
		resBody  = response.getBody();
		bodyJson = resBody.jsonPath();
		
	}
	
	
	//Kiểm tra status code
	@Test(priority = 0)
	public void TC01_LoginSuccessStatusCode200OK() {
		PropertiesFileUtils.getStatus(response, 200);
	}
	
	//Kiểm tra trường phản hồi message
	@Test(priority = 1)
	public void TC02_ValidateMessage() {
		PropertiesFileUtils.ContainKey(resBody, "message");
		PropertiesFileUtils.ContainValue(bodyJson, "message");
		PropertiesFileUtils.CompareValue(bodyJson, "message", "Đăng nhập thành công");
	}
	
	//Kiểm tra trường EmployerId trùng với thông tin đăng nhập
	@Test(priority = 2)
	public void TC03_ValidateEmployerID() {
		PropertiesFileUtils.ContainKey(resBody, "user");
		PropertiesFileUtils.ContainKeyInField(bodyJson, "user", "id");
		Assert.assertEquals(bodyJson.getInt("user.id"), Integer.parseInt(PropertiesFileUtils.getProperties("idEmployer")),"Trường id phản hồi không giống đăng ký");
		
	}
	
	//Kiểm tra trường account trùng với thông tin đăng nhập
		@Test(priority = 3)
		public void TC04_ValidateAccount() {
			PropertiesFileUtils.ContainKey(resBody, "user");
			PropertiesFileUtils.ContainKeyInField(bodyJson, "user", "account");
			Assert.assertEquals(bodyJson.get("user.account"), PropertiesFileUtils.getProperties("account_employer(success)"),"Trường account phản hồi không giống đăng nhập");
		}
		
	//Kiểm tra phản hồi thông tin "name" của employer
		@Test(priority = 4)
		public void TC05_ValidateName() {
			PropertiesFileUtils.ContainKey(resBody, "user");
			PropertiesFileUtils.ContainKeyInField(bodyJson, "user", "name");
			Assert.assertEquals(bodyJson.get("user.name"), PropertiesFileUtils.getProperties("name_employer"),"Trường name phản hồi không giống đăng nhập");
		}
		
		//Kiểm tra phản hồi thông tin "password" của employer
		@Test(priority = 5)
		public void TC06_ValidatePassword() {
			PropertiesFileUtils.ContainKey(resBody, "user");
			PropertiesFileUtils.ContainKeyInField(bodyJson, "user", "password");
			Assert.assertEquals(bodyJson.get("user.password"), PropertiesFileUtils.getProperties("password_employer(success)"),"Trường password phản hồi không giống đăng nhập");
		}
		
		//Kiểm tra phản hồi thông tin "phone" của employer
		@Test(priority = 6)
		public void TC07_ValidatePhone() {
			PropertiesFileUtils.ContainKey(resBody, "user");
			PropertiesFileUtils.ContainKeyInField(bodyJson, "user", "numberPhone");
			Assert.assertEquals(bodyJson.get("user.numberPhone"), PropertiesFileUtils.getProperties("numberPhone_employer"),"Trường phone phản hồi không giống đăng nhập");
				}
		
		//Kiểm tra phản hồi thông tin "address" của employer
		@Test(priority = 7)
		public void TC08_ValidateAddress() {
			PropertiesFileUtils.ContainKey(resBody, "user");
			PropertiesFileUtils.ContainKeyInField(bodyJson, "user", "address");
			Assert.assertEquals(bodyJson.get("user.address"), PropertiesFileUtils.getProperties("address_employer"),"Trường address phản hồi không giống đăng nhập");
				}
		//Kiểm tra phản hồi thông tin "nation" của employer
		@Test(priority = 8)
		public void TC09_ValidateNation() {
			PropertiesFileUtils.ContainKey(resBody, "user");
			PropertiesFileUtils.ContainKeyInField(bodyJson, "user", "nation");
			Assert.assertEquals(bodyJson.get("user.nation"), PropertiesFileUtils.getProperties("nation_employer"),"Trường nation phản hồi không giống đăng nhập");
				}
		
		//Kiểm tra phản hồi thông tin "webstie" của employer
		@Test(priority = 9)
		public void TC10_ValidateWebstie() {
			PropertiesFileUtils.ContainKey(resBody, "user");
			PropertiesFileUtils.ContainKeyInField(bodyJson, "user", "webstie");
			Assert.assertEquals(bodyJson.get("user.webstie"), PropertiesFileUtils.getProperties("webstie_employer"),"Trường webstie phản hồi không giống đăng nhập");
				}
		
		//Kiểm tra phản hồi thông tin "email" của employer
		@Test(priority = 10)
		public void TC11_ValidateEmail() {
			PropertiesFileUtils.ContainKey(resBody, "user");
			PropertiesFileUtils.ContainKeyInField(bodyJson, "user", "email");
			Assert.assertEquals(bodyJson.get("user.email"), PropertiesFileUtils.getProperties("email_employer"),"Trường email phản hồi không giống đăng nhập");
				}
		
		//Kiểm tra phản hồi thông tin "token" của employer	
		@Test(priority = 11)
		public void TC12_ValidateTokenEmployer() {
			PropertiesFileUtils.ContainKey(resBody, "token");
			PropertiesFileUtils.ContainValue(bodyJson, "token");
			PropertiesFileUtils.setProperty("tokenEmployer", bodyJson.getString("token"));
		}
}