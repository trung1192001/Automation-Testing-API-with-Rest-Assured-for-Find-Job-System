package Get_All_Company;

import org.apache.http.params.CoreConnectionPNames;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.api.auto.utils.PropertiesFileUtils;

import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_GetAllCompanySuccess {
	private Response response;
	private ResponseBody resBody;
	private JsonPath bodyJson;
	
	@BeforeClass
	public void Init() {
		
		HttpClientConfig httpClientConfig = HttpClientConfig
				.httpClientConfig()
				.setParam(CoreConnectionPNames.SO_TIMEOUT, 5000)
				.setParam(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);

		RestAssured.config = RestAssuredConfig.config().httpClient(httpClientConfig);

		RequestSpecification req = RestAssured.given();			
		
		response = req.get("http://34.143.239.189:5000/api/company/getAllCompany");
		resBody  = response.getBody();
		bodyJson = resBody.jsonPath();
		
	}
	
	//Kiểm tra status code
		@Test(priority = 0)
		public void TC01_GetAllCompanySuccessStatusCode200OK() {
			PropertiesFileUtils.getStatus(response, 200);
		}
		
		//Kiểm tra thông tin id Company ở các phần tử trong danh sách
		@Test(priority = 1)
		public void TC02_ValidateCompanyID() {
			for(int i = 0; i < bodyJson.getList("").size(); i++) {
				Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("id"), "Phần tử thứ " + i + " không có thông tin id");
				Assert.assertTrue(bodyJson.get("["+ i + "].id") != null ,"Thông tin id ở phần tử thứ " + i + " không hiển thị giá trị");
			}
		}
		
		//Kiểm tra thông tin "account" hiển thị ở các phần tử trong danh sách
			@Test(priority = 2)
			public void TC03_ValidateAccount() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("account"), "Phần tử thứ " + i + " không có thông tin account");
					Assert.assertTrue(bodyJson.get("["+ i + "].account") != null ,"Thông tin account ở phần tử thứ " + i + " không hiển thị giá trị");
				}
			}
			
		//Kiểm tra thông tin "name" hiển thị ở các phần tử trong danh sách
			@Test(priority = 3)
			public void TC04_ValidateName() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("name"), "Phần tử thứ " + i + " không có thông tin name");
					Assert.assertTrue(bodyJson.get("["+ i + "].name") != null ,"Thông tin name ở phần tử thứ " + i + " không hiển thị giá trị");
				}
			}
			
			//Kiểm tra thông tin "password" hiển thị ở các phần tử trong danh sách
			@Test(priority = 4)
			public void TC05_ValidatePassword() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("password"), "Phần tử thứ " + i + " không có thông tin password");
					Assert.assertTrue(bodyJson.get("["+ i + "].password") != null ,"Thông tin password ở phần tử thứ " + i + " không hiển thị giá trị");
				}
			}
			
			//Kiểm tra thông tin "address" hiển thị ở các phần tử trong danh sách
			@Test(priority = 5)
			public void TC06_ValidateAddress() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("address"), "Phần tử thứ " + i + " không có thông tin address");
					Assert.assertTrue(bodyJson.get("["+ i + "].address") != null ,"Thông tin address ở phần tử thứ " + i + " không hiển thị giá trị");
				}
			}
			
			//Kiểm tra thông tin "nation" hiển thị ở các phần tử trong danh sách
			@Test(priority = 6)
			public void TC07_ValidateNation() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("nation"), "Phần tử thứ " + i + " không có thông tin nation");
					Assert.assertTrue(bodyJson.get("["+ i + "].nation") != null ,"Thông tin nation ở phần tử thứ " + i + " không hiển thị giá trị");
				}
			}
			
			//Kiểm tra thông tin "webstie" hiển thị ở các phần tử trong danh sách
			@Test(priority = 7)
			public void TC08_ValidateWebstie() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("webstie"), "Phần tử thứ " + i + " không có thông tin webstie");
					Assert.assertTrue(bodyJson.get("["+ i + "].webstie") != null ,"Thông tin webstie ở phần tử thứ " + i + " không hiển thị giá trị");
				}
			}
			
			//Kiểm tra thông tin "experience" hiển thị ở các phần tử trong danh sách
			@Test(priority = 8)
			public void TC9_ValidateExperience() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("address"), "Phần tử thứ " + i + " không có thông tin address");
					Assert.assertTrue(bodyJson.get("["+ i + "].address") != null ,"Thông tin address ở phần tử thứ " + i + " không hiển thị giá trị");
				}
			}
			
			//Kiểm tra thông tin "email" hiển thị ở các phần tử trong danh sách
			@Test(priority = 9)
			public void TC10_ValidateEmail() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("email"), "Phần tử thứ " + i + " không có thông tin email");
					Assert.assertTrue(bodyJson.get("["+ i + "].email") != null ,"Thông tin email ở phần tử thứ " + i + " không hiển thị giá trị");
				}
			}
			
			//Kiểm tra thông tin "avatar" hiển thị ở các phần tử trong danh sách
			@Test(priority = 10)
			public void TC11_ValidateAvatar() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("avatar"), "Phần tử thứ " + i + " không có thông tin avatar");
					Assert.assertTrue(bodyJson.get("["+ i + "].avatar") != null ,"Thông tin avatar ở phần tử thứ " + i + " không hiển thị giá trị");
						}
			}
			
			//Kiểm tra thông tin "numberPhone" hiển thị ở các phần tử trong danh sách
			@Test(priority = 11)
			public void TC12_ValidateNumberPhone() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("numberPhone"), "Phần tử thứ " + i + " không có thông tin numberPhone");
					Assert.assertTrue(bodyJson.get("["+ i + "].numberPhone") != null ,"Thông tin numberPhone ở phần tử thứ " + i + " không hiển thị giá trị");
						}
			}
			
}
