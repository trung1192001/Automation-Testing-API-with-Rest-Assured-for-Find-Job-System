package Get_All_User;

import org.apache.http.params.CoreConnectionPNames;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.api.auto.utils.PropertiesFileUtils;

import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_GetAllUserSuccess {
	private Response response;
	private ResponseBody resBody;
	private JsonPath bodyJson;
	
	@BeforeClass
	public void Init() {
		
		HttpClientConfig httpClientConfig = HttpClientConfig
				.httpClientConfig()
				.setParam(CoreConnectionPNames.SO_TIMEOUT, 5000)
				.setParam(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);

		RestAssured.config = RestAssuredConfig.config().httpClient(httpClientConfig);

		RequestSpecification req = RestAssured.given();			
		
		response = req.get("http://34.143.239.189:5000/api/users/getAllUsers");
		resBody  = response.getBody();
		bodyJson = resBody.jsonPath();
		
	}
	
	@Test(priority = 0)
	public void TC_GetAllUserSuccessStatusCode200() {
		Assert.assertEquals(response.getStatusCode(), 200);
	}
	
	//Kiểm tra thông tin idUser ở các phần tử trong danh sách
		@Test(priority = 1)
		public void TC02_ValidateUserID() {
			for(int i = 0; i < bodyJson.getList("").size(); i++) {
				Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("id"), "Phần tử thứ " + i + " không có thông tin id");
				Assert.assertTrue(bodyJson.get("["+ i + "].id") != null ,"Thông tin id ở phần tử thứ " + i + " không hiển thị giá trị");
			}
		}
		
		//Kiểm tra thông tin "account" hiển thị ở các phần tử trong danh sách
			@Test(priority = 2)
			public void TC03_ValidateAccount() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("account"), "Phần tử thứ " + i + " không có thông tin account");
					Assert.assertTrue(bodyJson.getString("["+ i + "].account").length() > 0,"Thông tin account ở phần tử thứ " + i + " không hiển thị giá trị");
				}
			}
			
		//Kiểm tra thông tin "name" hiển thị ở các phần tử trong danh sách
			@Test(priority = 3)
			public void TC04_ValidateName() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("name"), "Phần tử thứ " + i + " không có thông tin name");
					Assert.assertTrue(bodyJson.getString("["+ i + "].name").length() > 0,"Thông tin name ở phần tử thứ " + i + " không hiển thị giá trị");
				}
			}
			
			//Kiểm tra thông tin "password" hiển thị ở các phần tử trong danh sách
			@Test(priority = 4)
			public void TC05_ValidatePassword() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("password"), "Phần tử thứ " + i + " không có thông tin password");
					Assert.assertTrue(bodyJson.getString("["+ i + "].password").length() > 0,"Thông tin password ở phần tử thứ " + i + " không hiển thị giá trị");
				}
			}
			
			//Kiểm tra thông tin "phone" hiển thị ở các phần tử trong danh sách
			@Test(priority = 5)
			public void TC06_ValidatePhone() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("phone"), "Phần tử thứ " + i + " không có thông tin phone");
					Assert.assertTrue(bodyJson.getString("["+ i + "].phone").length() > 0,"Thông tin phone ở phần tử thứ " + i + " không hiển thị giá trị");
				}
			}
			
			//Kiểm tra thông tin "sex" hiển thị ở các phần tử trong danh sách
			@Test(priority = 6)
			public void TC07_ValidateSex() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("sex"), "Phần tử thứ " + i + " không có thông tin sex");
					Assert.assertTrue(bodyJson.getString("["+ i + "].sex").length() > 0,"Thông tin sex ở phần tử thứ " + i + " không hiển thị giá trị");
				}
			}
			
			//Kiểm tra thông tin "birthday" hiển thị ở các phần tử trong danh sách
			@Test(priority = 7)
			public void TC08_ValidateBirthday() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("birthday"), "Phần tử thứ " + i + " không có thông tin birthday");
					Assert.assertTrue(bodyJson.getString("["+ i + "].birthday").length() > 0,"Thông tin birthday ở phần tử thứ " + i + " không hiển thị giá trị");
				}
			}
			
			//Kiểm tra thông tin "experience" hiển thị ở các phần tử trong danh sách
			@Test(priority = 8)
			public void TC9_ValidateExperience() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("experience"), "Phần tử thứ " + i + " không có thông tin experience");
				}
			}
			
			//Kiểm tra thông tin "skill" hiển thị ở các phần tử trong danh sách
			@Test(priority = 9)
			public void TC10_ValidateSkill() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("skill"), "Phần tử thứ " + i + " không có thông tin skill");
				}
			}
			
			//Kiểm tra thông tin "nation" hiển thị ở các phần tử trong danh sách
			@Test(priority = 10)
			public void TC11_ValidateNation() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("nation"), "Phần tử thứ " + i + " không có thông tin nation");
						}
			}
			
			//Kiểm tra thông tin "description" hiển thị ở các phần tử trong danh sách
			@Test(priority = 11)
			public void TC12_ValidateDescription() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("description"), "Phần tử thứ " + i + " không có thông tin description");
						}
			}
			
			//Kiểm tra thông tin "foreiginLanguage" hiển thị ở các phần tử trong danh sách
			@Test(priority = 12)
			public void TC13_ValidateForeiginLanguage() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("foreiginLanguage"), "Phần tử thứ " + i + " không có thông tin foreiginLanguage");
				}
			}
			
			//Kiểm tra thông tin "education" hiển thị ở các phần tử trong danh sách
			@Test(priority = 13)
			public void TC14_ValidateEducation() {
				for(int i = 0; i < bodyJson.getList("").size(); i++) {
					Assert.assertTrue(bodyJson.get("["+ i + "]").toString().contains("education"), "Phần tử thứ " + i + " không có thông tin education");
				}
			}
}
