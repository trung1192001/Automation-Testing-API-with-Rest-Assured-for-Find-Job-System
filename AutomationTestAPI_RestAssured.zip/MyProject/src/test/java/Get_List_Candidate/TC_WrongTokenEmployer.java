package Get_List_Candidate;

import org.apache.http.params.CoreConnectionPNames;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.api.auto.utils.PropertiesFileUtils;

import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_WrongTokenEmployer {
	private Response response;
	private ResponseBody resBody;
	private JsonPath bodyJson;
	
	@BeforeClass
	public void Init() {
		
		HttpClientConfig httpClientConfig = HttpClientConfig
				.httpClientConfig()
				.setParam(CoreConnectionPNames.SO_TIMEOUT, 5000)
				.setParam(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);

		RestAssured.config = RestAssuredConfig.config().httpClient(httpClientConfig);
		
		RequestSpecification req = RestAssured.given()
				.header("Token","wrongToken");
		
		response = req.get("http://34.143.239.189:5000/api/work-user/get-all-admin");
		resBody  = response.getBody();
		bodyJson = resBody.jsonPath();

	}
	
	
	//Kiểm tra status code
	@Test
	public void TC01_WrongTokenEmployerStatusCode403() {
		PropertiesFileUtils.getStatus(response, 403);
	}
}
