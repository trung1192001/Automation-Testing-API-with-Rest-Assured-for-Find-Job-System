package Get_List_Work;

import org.apache.http.params.CoreConnectionPNames;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.api.auto.utils.PropertiesFileUtils;

import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_GetListWorkSuccess {
	private Response response;
	private ResponseBody resBody;
	private JsonPath bodyJson;
	
	@BeforeClass
	public void Init() {
		
		HttpClientConfig httpClientConfig = HttpClientConfig
				.httpClientConfig()
				.setParam(CoreConnectionPNames.SO_TIMEOUT, 5000)
				.setParam(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);

		RestAssured.config = RestAssuredConfig.config().httpClient(httpClientConfig);
		
		RequestSpecification req = RestAssured.given();			
		
		response = req.get("http://34.143.239.189:5000/api/work/list-work");
		resBody  = response.getBody();
		bodyJson = resBody.jsonPath();

	}
	
	//Kiểm tra status code
	@Test(priority = 0)
	public void TC01_GetListWorkStatusCode200OK() {
		PropertiesFileUtils.getStatus(response, 200);
	}
	
	//Kiểm tra trả về danh sách công việc
	@Test(priority = 1)
	public void TC02_ResponseListWork() {
		Assert.assertFalse(bodyJson.getList("").isEmpty(), "Không có công việc trong danh sách");
	}
	
	//Lấy thông tin jobId
	@Test(priority = 2)
	public void TC03_SaveJobId() {
		Assert.assertTrue(bodyJson.get("[0]").toString().contains("id"));
		Assert.assertTrue(bodyJson.get("[0].id") != null, "Thông tin JobId không có dữ liệu");
		PropertiesFileUtils.setProperty("JobId", "" + bodyJson.getInt("[0].id") + "");
		}
}
