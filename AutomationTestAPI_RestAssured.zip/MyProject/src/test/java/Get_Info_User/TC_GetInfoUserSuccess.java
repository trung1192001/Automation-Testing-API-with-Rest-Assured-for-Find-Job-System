package Get_Info_User;

import org.apache.http.params.CoreConnectionPNames;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.api.auto.utils.PropertiesFileUtils;

import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_GetInfoUserSuccess {
	private Response response;
	private ResponseBody resBody;
	private JsonPath bodyJson;
	
	@BeforeClass
	public void Init() {
		
		HttpClientConfig httpClientConfig = HttpClientConfig
				.httpClientConfig()
				.setParam(CoreConnectionPNames.SO_TIMEOUT, 5000)
				.setParam(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);

		RestAssured.config = RestAssuredConfig.config().httpClient(httpClientConfig);
		
		RequestSpecification req = RestAssured.given()
								.header("Token",PropertiesFileUtils.getProperties("tokenUser"));
		
		response = req.get("http://34.143.239.189:5000/api/users/get-information-user");
		resBody  = response.getBody();
		bodyJson = resBody.jsonPath();

	}
	
	
	//Kiểm tra status code
	@Test(priority = 0)
	public void TC01_GetInfoUserSuccessStatusCode200OK() {
		PropertiesFileUtils.getStatus(response, 200);
	}
	
	//Kiểm tra trường userId trùng với thông tin đăng nhập
	@Test(priority = 1)
	public void TC02_ValidateUserID() {
		PropertiesFileUtils.ContainKey(resBody, "id");
		Assert.assertEquals(bodyJson.getInt("id"), Integer.parseInt(PropertiesFileUtils.getProperties("idUser")),"Trường id phản hồi không giống đăng ký");
		
	}
	
	//Kiểm tra trường account trùng với thông tin đăng nhập
		@Test(priority = 2)
		public void TC03_ValidateAccount() {
			PropertiesFileUtils.ContainKey(resBody, "account");
			Assert.assertEquals(bodyJson.get("account"), PropertiesFileUtils.getProperties("account"),"Trường account phản hồi không giống đăng ký");
		}
		
	//Kiểm tra phản hồi thông tin "name" của user
		@Test(priority = 3)
		public void TC04_ValidateName() {
			PropertiesFileUtils.ContainKey(resBody, "name");
			Assert.assertEquals(bodyJson.get("name"), PropertiesFileUtils.getProperties("name"),"Trường name phản hồi không giống đăng nhập");
		}
		
		//Kiểm tra phản hồi thông tin "password" của user
		@Test(priority = 4)
		public void TC05_ValidatePassword() {
			PropertiesFileUtils.ContainKey(resBody, "password");
			Assert.assertEquals(bodyJson.get("password"), PropertiesFileUtils.getProperties("password"),"Trường password phản hồi không giống đăng nhập");
		}
		
		//Kiểm tra phản hồi thông tin "phone" của user
		@Test(priority = 5)
		public void TC06_ValidatePhone() {
			PropertiesFileUtils.ContainKey(resBody, "phone");
			Assert.assertEquals(bodyJson.get("phone"), PropertiesFileUtils.getProperties("phone"),"Trường phone phản hồi không giống đăng nhập");
				}
		
		//Kiểm tra phản hồi thông tin "sex" của user
		@Test(priority = 6)
		public void TC07_ValidateSex() {
			PropertiesFileUtils.ContainKey(resBody, "sex");
			Assert.assertEquals(bodyJson.get("sex"), PropertiesFileUtils.getProperties("sex"),"Trường sex phản hồi không giống đăng nhập");
				}
		
		//Kiểm tra phản hồi thông tin "birthday" của user
		@Test(priority = 7)
		public void TC08_ValidateBirthday() {
			PropertiesFileUtils.ContainKey(resBody, "birthday");
			Assert.assertEquals(bodyJson.get("birthday"), PropertiesFileUtils.getProperties("birthday"),"Trường birthday phản hồi không giống đăng nhập");
				}
		
		//Kiểm tra phản hồi thông tin "experience" của user
		@Test(priority = 8)
		public void TC09_ValidateExperience() {
			PropertiesFileUtils.ContainKey(resBody, "experience");
			Assert.assertEquals(bodyJson.get("experience"), PropertiesFileUtils.getProperties("experience"),"Trường experience phản hồi không giống đăng nhập");
				}
		
		//Kiểm tra phản hồi thông tin "skill" của user
		@Test(priority = 9)
		public void TC10_ValidateSkill() {
			PropertiesFileUtils.ContainKey(resBody, "skill");
			Assert.assertEquals(bodyJson.get("skill"), PropertiesFileUtils.getProperties("skill"),"Trường skill phản hồi không giống đăng nhập");
				}
		
		//Kiểm tra phản hồi thông tin "description" của user	
		@Test(priority = 10)
		public void TC11_ValidateDescription() {
			PropertiesFileUtils.ContainKey(resBody, "description");
			Assert.assertEquals(bodyJson.get("description"), PropertiesFileUtils.getProperties("description"),"Trường description phản hồi không giống đăng nhập");
				}
		
		//Kiểm tra phản hồi thông tin "foreiginLanguage" của user	
		@Test(priority = 11)
		public void TC12_ValidateForeiginLanguage() {
			PropertiesFileUtils.ContainKey(resBody, "foreiginLanguage");
			Assert.assertEquals(bodyJson.get("foreiginLanguage"), PropertiesFileUtils.getProperties("foreiginLanguage"),"Trường foreiginLanguage phản hồi không giống đăng nhập");
				}
		
		//Kiểm tra phản hồi thông tin "education" của user	
		@Test(priority = 12)
		public void TC13_ValidateEducation() {
			PropertiesFileUtils.ContainKey(resBody, "education");
			Assert.assertEquals(bodyJson.get("education"), PropertiesFileUtils.getProperties("education"),"Trường education phản hồi không giống đăng nhập");
				}
		
}
