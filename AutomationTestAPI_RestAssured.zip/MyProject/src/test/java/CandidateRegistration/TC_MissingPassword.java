package CandidateRegistration;

import java.io.File;

import org.apache.http.params.CoreConnectionPNames;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.api.auto.utils.PropertiesFileUtils;

import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_MissingPassword {
	private Response response;
	private ResponseBody resBody;
	private JsonPath bodyJson;
	
	//Thiết lập cho trường hợp "password" bị thiếu
	@BeforeClass
	public void MissingPassword() {
				String account = PropertiesFileUtils.setRandomValueAccount();
				String email = account + "@gmail.com";
				String phone = PropertiesFileUtils.setRandomNumber();
				
				PropertiesFileUtils.setProperty("email", email);
				PropertiesFileUtils.setProperty("account", account);
				PropertiesFileUtils.setProperty("phone", phone);
				
				File fileAvatar = new File("./configuration/Logo-BK-HoChiMinh.png");
				
				HttpClientConfig httpClientConfig = HttpClientConfig
						.httpClientConfig()
						.setParam(CoreConnectionPNames.SO_TIMEOUT, 5000)
						.setParam(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);

				RestAssured.config = RestAssuredConfig.config().httpClient(httpClientConfig);
				
				RequestSpecification req = RestAssured.given()
						.multiPart("avatar", fileAvatar)
						.formParam("name", PropertiesFileUtils.getProperties("name"))
						.formParam("email", PropertiesFileUtils.getProperties("email"))
						.formParam("account", PropertiesFileUtils.getProperties("account"))
						.formParam("phone", PropertiesFileUtils.getProperties("phone"))
						.formParam("sex", PropertiesFileUtils.getProperties("sex"))
						.formParam("birthday", PropertiesFileUtils.getProperties("birthday"))
						.formParam("experience", PropertiesFileUtils.getProperties("experience"))
						.formParam("skill", PropertiesFileUtils.getProperties("skill"))
						.formParam("description", PropertiesFileUtils.getProperties("description"))
						.formParam("foreiginLanguage", PropertiesFileUtils.getProperties("foreiginLanguage"))
						.formParam("education", PropertiesFileUtils.getProperties("education"))
						.contentType(ContentType.MULTIPART);
						
				response = req.post("http://34.143.239.189:5000/api/users/register");
				resBody = response.getBody();
				bodyJson = resBody.jsonPath();

			}
	
	@Test
	public void TC_MissingPasswordStatusCode500() {
			PropertiesFileUtils.getStatus(response, 500);
		}

	@AfterClass
	public void Reset() {
		try {
			PropertiesFileUtils.setProperty("sex", "Nam");
			PropertiesFileUtils.setProperty("birthday", "11/09/2001");
			PropertiesFileUtils.setProperty("password", "Abcd1234@");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
