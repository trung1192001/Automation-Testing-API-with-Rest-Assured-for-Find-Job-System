package CandidateRegistration;

import java.io.File;

import org.apache.http.params.CoreConnectionPNames;
import org.ietf.jgss.Oid;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.api.auto.utils.PropertiesFileUtils;

import groovy.lang.Newify;
import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_RegisterSuccess {
	private Response response;
	private ResponseBody resBody;
	private JsonPath bodyJson;
	
	@BeforeClass
	public void Init() {
		String account = PropertiesFileUtils.setRandomValueAccount();
		String email = account + "@gmail.com";
		String phone = PropertiesFileUtils.setRandomNumber();
		
		PropertiesFileUtils.setProperty("account", account);
		PropertiesFileUtils.setProperty("email", email);
		PropertiesFileUtils.setProperty("phone", phone);
		
		File fileAvatar = new File("./configuration/Logo-BK-HoChiMinh.png");
		
		HttpClientConfig httpClientConfig = HttpClientConfig
				.httpClientConfig()
				.setParam(CoreConnectionPNames.SO_TIMEOUT, 5000)
				.setParam(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);

		RestAssured.config = RestAssuredConfig.config().httpClient(httpClientConfig);
		
		RequestSpecification req = RestAssured.given()
				.multiPart("avatar", fileAvatar)
				.formParam("name", PropertiesFileUtils.getProperties("name"))
				.formParam("email", PropertiesFileUtils.getProperties("email"))
				.formParam("account", PropertiesFileUtils.getProperties("account"))
				.formParam("password", PropertiesFileUtils.getProperties("password"))
				.formParam("phone", PropertiesFileUtils.getProperties("phone"))
				.formParam("sex", PropertiesFileUtils.getProperties("sex"))
				.formParam("birthday", PropertiesFileUtils.getProperties("birthday"))
				.formParam("experience", PropertiesFileUtils.getProperties("experience"))
				.formParam("skill", PropertiesFileUtils.getProperties("skill"))
				.formParam("description", PropertiesFileUtils.getProperties("description"))
				.formParam("foreiginLanguage", PropertiesFileUtils.getProperties("foreiginLanguage"))
				.formParam("education", PropertiesFileUtils.getProperties("education"))
				.contentType(ContentType.MULTIPART);
				
		response = req.post("http://34.143.239.189:5000/api/users/register");
		resBody = response.getBody();
		bodyJson = resBody.jsonPath();

	}
	
	@Test(priority = 0) 
	public void TC01_Status201Created() {
		PropertiesFileUtils.getStatus(response, 201);
	}
	
	@Test(priority = 1)
	public void TC02_ValidateName() {
		PropertiesFileUtils.ContainKey(resBody, "name");
		PropertiesFileUtils.ContainValue(bodyJson, "name");
		PropertiesFileUtils.CompareValue(bodyJson, "name", PropertiesFileUtils.getProperties("name"));
	}
	
	@Test(priority = 2)
	public void TC03_ValidateEmail() {
		PropertiesFileUtils.ContainKey(resBody, "email");
		PropertiesFileUtils.ContainValue(bodyJson, "email");
		PropertiesFileUtils.CompareValue(bodyJson, "email", PropertiesFileUtils.getProperties("email"));
	}
	
	@Test(priority = 3)
	public void TC04_ValidateAccount() {
		PropertiesFileUtils.ContainKey(resBody, "account");
		PropertiesFileUtils.ContainValue(bodyJson, "account");
		PropertiesFileUtils.CompareValue(bodyJson, "account", PropertiesFileUtils.getProperties("account"));
		PropertiesFileUtils.setProperty("account_user(success)", bodyJson.getString("account"));
	}
	
	@Test(priority = 4)
	public void TC05_ValidatePassword() {
		PropertiesFileUtils.ContainKey(resBody, "password");
		PropertiesFileUtils.ContainValue(bodyJson, "password");
		PropertiesFileUtils.CompareValue(bodyJson, "password", PropertiesFileUtils.getProperties("password"));
		PropertiesFileUtils.setProperty("password_user(success)", bodyJson.getString("password"));
	}
	
	@Test(priority = 5)
	public void TC06_ValidatePhone() {
		PropertiesFileUtils.ContainKey(resBody, "phone");
		PropertiesFileUtils.ContainValue(bodyJson, "phone");
		PropertiesFileUtils.CompareValue(bodyJson, "phone", PropertiesFileUtils.getProperties("phone"));
		PropertiesFileUtils.setProperty("phone_success", bodyJson.getString("phone"));
	}
	
	@Test(priority = 6)
	public void TC07_ValidateSex() {
		PropertiesFileUtils.ContainKey(resBody, "sex");
		PropertiesFileUtils.ContainValue(bodyJson, "sex");
		PropertiesFileUtils.CompareValue(bodyJson, "sex", PropertiesFileUtils.getProperties("sex"));
	}
	
	@Test(priority = 7)
	public void TC08_ValidateBirthday() {
		PropertiesFileUtils.ContainKey(resBody, "birthday");
		PropertiesFileUtils.ContainValue(bodyJson, "birthday");
		PropertiesFileUtils.CompareValue(bodyJson, "birthday", PropertiesFileUtils.getProperties("birthday"));
	}
	
	@Test(priority = 8)
	public void TC09_ValidateExperience() {
		PropertiesFileUtils.ContainKey(resBody, "experience");
		PropertiesFileUtils.ContainValue(bodyJson, "experience");
		PropertiesFileUtils.CompareValue(bodyJson, "experience", PropertiesFileUtils.getProperties("experience"));
	}
	
	@Test(priority = 9)
	public void TC10_ValidateSkill() {
		PropertiesFileUtils.ContainKey(resBody, "skill");
		PropertiesFileUtils.ContainValue(bodyJson, "skill");
		PropertiesFileUtils.CompareValue(bodyJson, "skill", PropertiesFileUtils.getProperties("skill"));
	}
	
	@Test(priority = 10)
	public void TC11_ValidateDescription() {
		PropertiesFileUtils.ContainKey(resBody, "description");
		PropertiesFileUtils.ContainValue(bodyJson, "description");
		PropertiesFileUtils.CompareValue(bodyJson, "description", PropertiesFileUtils.getProperties("description"));
	}
	
	@Test(priority = 11)
	public void TC12_ValidateForeiginLanguage() {
		PropertiesFileUtils.ContainKey(resBody, "foreiginLanguage");
		PropertiesFileUtils.ContainValue(bodyJson, "foreiginLanguage");
		PropertiesFileUtils.CompareValue(bodyJson, "foreiginLanguage", PropertiesFileUtils.getProperties("foreiginLanguage"));
	}
	
	@Test(priority = 12)
	public void TC13_ValidateEducation() {
		PropertiesFileUtils.ContainKey(resBody, "education");
		PropertiesFileUtils.ContainValue(bodyJson, "education");
		PropertiesFileUtils.CompareValue(bodyJson, "education", PropertiesFileUtils.getProperties("education"));
	}
	
	@Test(priority = 13)
	public void TC14_ValidateID() {
		PropertiesFileUtils.ContainKey(resBody, "id");
		PropertiesFileUtils.ContainValue(bodyJson, "id");
		PropertiesFileUtils.setProperty("idUser", bodyJson.getString("id"));
	}
}
