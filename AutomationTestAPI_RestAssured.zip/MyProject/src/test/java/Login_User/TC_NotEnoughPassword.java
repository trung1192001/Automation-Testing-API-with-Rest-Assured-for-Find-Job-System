package Login_User;

import org.apache.http.params.CoreConnectionPNames;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.api.auto.utils.PropertiesFileUtils;

import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_NotEnoughPassword {
	private Response response;
	private ResponseBody resBody;
	private JsonPath bodyJson;
		
	@BeforeClass
	public void Init() {
		String bodyInfo = "{\"account\" : \"" + PropertiesFileUtils.getProperties("account_user(success)") + "\", \"password\" : \""
				+ PropertiesFileUtils.getProperties("not_enough_password") + "\"}";

		HttpClientConfig httpClientConfig = HttpClientConfig
				.httpClientConfig()
				.setParam(CoreConnectionPNames.SO_TIMEOUT, 5000)
				.setParam(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);

		RestAssured.config = RestAssuredConfig.config().httpClient(httpClientConfig);

		RequestSpecification req = RestAssured.given()
								.contentType(ContentType.JSON)
								.body(bodyInfo);
		
		response = req.post("http://34.143.239.189:5000/api/users/login");
		resBody  = response.getBody();
		bodyJson = resBody.jsonPath();

	}
	
	//Kiểm tra status code
	@Test(priority = 0)
	public void TC01_NotEnoughPasswordStatusCode400() {
		PropertiesFileUtils.getStatus(response, 400);
	}
	
	//Kiểm tra trường phản hồi message
	@Test(priority = 1)
	public void TC02_ValidateMessage() {
		PropertiesFileUtils.ContainKey(resBody, "message");
		PropertiesFileUtils.ContainValue(bodyJson, "message");
		PropertiesFileUtils.CompareValue(bodyJson, "message", " Mật khẩu không hợp lệ, mật khẩu phải tối thiểu 8 kí tự, bao gồm chữ hoa, thường, số");
	}
	
}
