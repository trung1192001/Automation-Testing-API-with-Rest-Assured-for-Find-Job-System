package Get_All_Application;

import java.util.concurrent.TimeoutException;

import org.apache.http.params.CoreConnectionPNames;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class TC_GetAllApplicationSuccess {
	private Response response;
	private ResponseBody resBody;
	private JsonPath bodyJson;
	
	@BeforeClass
	public void Init() {
		HttpClientConfig httpClientConfig = HttpClientConfig
											.httpClientConfig()
											.setParam(CoreConnectionPNames.SO_TIMEOUT, 5000)
											.setParam(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);

		RestAssured.config = RestAssuredConfig.config().httpClient(httpClientConfig);
		
		RequestSpecification req = RestAssured.given();			
		
		response = req.get("http://34.143.239.189:5000/api/application/getall-application");
		resBody  = response.getBody();
		bodyJson = resBody.jsonPath();

	}
	
	@Test
	public void TC_GetAllApplicationStatusCode200() {
		Assert.assertEquals(response.getStatusCode(), 200);
	}
}
